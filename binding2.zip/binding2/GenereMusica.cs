﻿using System.Collections.Generic;

namespace binding2
{
    class GenereMusica {
        public string Sigla{ get; set; }
        public string NomeGenere { get; set; }
        public List<Cantante> ListaCantanti;

        public GenereMusica(string sigla, string nomeGenere, List<Cantante> list)
        {
            Sigla = sigla;
            NomeGenere = nomeGenere;
            ListaCantanti = list;
        }
    }
}
